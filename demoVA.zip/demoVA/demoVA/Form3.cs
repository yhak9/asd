﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace demoVA
{
    public partial class Form3 : Form
    {
        private int _productId;
        public int user_id;
        string connection = @"Server=KRN-20-202-C05\MSSQLSERVER2;Database=Модуль1;Integrated Security=True;TrustServerCertificate=True;";

        public Form3(int productId)
        {
            InitializeComponent();
            _productId = productId;
        }

        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;

            LoadAvailableSizes();
        }

        // Загружаем в comboBox1 доступные размеры для выбранного товара (_productId)
        private void LoadAvailableSizes()
        {
            string query = @"SELECT DISTINCT 
                           s.size_id, 
                           s.size_value, 
                           st.available_quantity
                           FROM stock_items st
                           JOIN sizes s ON st.size_id = s.size_id
                           WHERE st.product_id = @ProductId AND st.available_quantity > 0
                           ORDER BY s.size_value";//запрос sql, distinct убирает дубли, join склеивает таблицы

            using (SqlConnection conn = new SqlConnection(connection))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@ProductId", _productId);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    comboBox1.DisplayMember = "size_value";
                    comboBox1.ValueMember = "size_id";
                    comboBox1.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при загрузке размеров: " + ex.Message);
                }
            }
        }

        // Когда выбрали размер в comboBox1, заполняем comboBox2 доступным количеством (от 1 до available_quantity)
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem is DataRowView row)
            {
                int maxQty = Convert.ToInt32(row["available_quantity"]);
                comboBox2.Items.Clear();
                for (int i = 1; i <= maxQty; i++)
                {
                    comboBox2.Items.Add(i);
                }
                if (comboBox2.Items.Count > 0)
                {
                    comboBox2.SelectedIndex = 0; // По умолчанию ставим 1 шт.
                }
            }
        }

        // Кнопка "Заказать"
        private void button1_Click(object sender, EventArgs e)
        {
            int sizeId = Convert.ToInt32(comboBox1.SelectedValue);
            int qty = Convert.ToInt32(comboBox2.Text);

            using (SqlConnection conn = new SqlConnection(connection))
            {
                conn.Open();

                // 1. Находим ID складской позиции
                SqlCommand cmd1 = new SqlCommand(@$"SELECT DISTINCT
                                                 stock_item_id 
                                                 FROM stock_items 
                                                 WHERE product_id = {_productId} 
                                                 AND size_id = {sizeId}", conn);
                int stockId = Convert.ToInt32(cmd1.ExecuteScalar());

                // 2. Создаём заказ и берём его ID
                SqlCommand cmd2 = new SqlCommand(@$"INSERT INTO
                                                 orders (user_id, order_date)
                                                 OUTPUT INSERTED.order_id VALUES ({(user_id > 0 ? user_id : 1)})", conn);
                int orderId = Convert.ToInt32(cmd2.ExecuteScalar());

                // 3. Записываем товар в заказ и списываем со склада
                SqlCommand cmd3 = new SqlCommand(@$"
            INSERT INTO order_items (order_id, stock_item_id, quantity) VALUES ({orderId}, {stockId}, {qty});
            UPDATE stock_items SET available_quantity = available_quantity - {qty} WHERE stock_item_id = {stockId};", conn);
                cmd3.ExecuteNonQuery();
            }

            MessageBox.Show("Заказ оформлен!");
            this.Close();
        }

        // Кнопка "Назад"
        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}