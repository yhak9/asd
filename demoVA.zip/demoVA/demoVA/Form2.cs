﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace demoVA
{
    public partial class Form2 : Form
    {
        public int user_id;
        string connection = "Server=KRN-20-202-C05\\MSSQLSERVER2;Database=Модуль1;Integrated Security=True;TrustServerCertificate=True";

        public Form2()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = textBox1.Text;
            if (login == "")
            {
                MessageBox.Show("Поле должны быть заполнены!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            SqlConnection sqlConnection = new SqlConnection(connection);
            sqlConnection.Open();

            string query = @"SELECT * FROM users WHERE login = @login";

            SqlCommand sqlCommand = new SqlCommand (query, sqlConnection);
            sqlCommand.Parameters.AddWithValue("login", login);
            SqlDataReader reader = sqlCommand.ExecuteReader();

            if (reader.Read())
            {
                MessageBox.Show("Успешный вход!", "Успех!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Form1 form1 = new Form1();
                form1.user_id = Convert.ToInt32(reader[0]);
                form1.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Неправильный логин!", "Ошибка!", MessageBoxButtons.OK);
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            button1.BackColor = ColorTranslator.FromHtml("#70B2AF");
        }
    }
}
