﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demoVA
{
    public partial class UserControl1 : UserControl
    {
        private int _productId;
        public UserControl1()
        {
            InitializeComponent();
            SubscribeClicks(this);
        }

        private void SubscribeClicks(Control parent)
        {
            parent.Click += OpenOrderForm;
            foreach (Control child in parent.Controls)
            {
                SubscribeClicks(child);
            }
        }

        private void OpenOrderForm(object sender, EventArgs e)
        {
            // Создаем Form3 и передаем туда ID выбранного товара
            Form3 form3 = new Form3(_productId);

            // Находим текущую Form2, чтобы скрыть её (по желанию)
            Form parentForm = this.FindForm();
            if (parentForm != null)
            {
                parentForm.Hide();
                // Когда Form3 закроется (по кнопке "Назад"), Form2 снова появится
                form3.FormClosed += (s, args) => parentForm.Show();
            }

            form3.Show();
        }

        public void Card(int id, string manuf, string productName, string cat, int quantity, string compos, decimal currentPrice, string imageFile) //метод заполнение карточки товара из Form1
        {
            _productId = id;
            label1.Text = manuf + " | " + productName;
            label3.Text = cat;
            if (quantity > 5)
            {
                label5.Text = "много";
            }
            else
            {
                label5.Text = "мало";
            }
            label4.Text = compos;
            currentPrice = currentPrice - currentPrice * 0.25m; //скидка 25%
            label2.Text = "Цена: " + currentPrice.ToString("N2") + " ₽"; //N2- 2 знака после запятой
            pictureBox1.Image = Image.FromFile(Path.Combine(Application.StartupPath, imageFile)); //загрузка изображения

            if (quantity <= 3)//подсветка картоки обувяя
            {
                BackColor = ColorTranslator.FromHtml("#FF8080");
            }
            else
            {
                BackColor = ColorTranslator.FromHtml("#D2F6E7");
            }
        }

    }
}
