using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace demoVA
{
    public partial class Form1 : Form
    {
        public int user_id;
        string connection = "Server=KRN-20-202-C05\\MSSQLSERVER2;Database=Модуль1;Integrated Security=True;TrustServerCertificate=True"; //подключение БД
        public Form1()
        {
            InitializeComponent();
        }



        private void Form1_Load_1(object sender, EventArgs e)
        {
            button1.BackColor = ColorTranslator.FromHtml("#70B2AF");
            SqlConnection sqlConnection = new SqlConnection(connection); //объект подключения
            sqlConnection.Open(); //открываем соединение с бд

            string queryUser = "SELECT * FROM users WHERE user_id = " + user_id;

            SqlCommand sqlCommandUser = new SqlCommand(queryUser, sqlConnection);
            SqlDataReader readerUser = sqlCommandUser.ExecuteReader();

            if (readerUser.Read())
            {
                label1.Text = readerUser[1].ToString() + " " + readerUser[2].ToString() + " " + readerUser[3].ToString();
            }
            readerUser.Close();

            string query = @"SELECT DISTINCT
                           products.product_id,
                           products.product_name, 
                           products.current_price, 
                           products.image_file, 
                           products.composition, 
                           manufacturers.manufacturer_name, 
                           categories.category_name,
                           stock_items.available_quantity
                           FROM products
                           JOIN manufacturers ON products.manufacturer_id = manufacturers.manufacturer_id
                           JOIN subcategories ON products.subcategory_id = subcategories.subcategory_id
                           JOIN stock_items ON stock_items.product_id = products.product_id
                           JOIN categories ON subcategories.category_id = categories.category_id"; //запрос sql, distinct убирает дубли, join склеивает таблицы

            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection); //создаем кманду: передаем текст запроса и объект подключения
            SqlDataReader reader = sqlCommand.ExecuteReader(); //выполняем запрос и получаем данные

            flowLayoutPanel1.Controls.Clear(); //очищаем панель

            while (reader.Read()) //проходим по кадой строке результата заброса, пока есть данные
            {
                UserControl1 userControl = new UserControl1(); //создание нов-го экземпляра поль з-го эл-та упр-я

                userControl.Card( //вызываем метод. заполняем катрочку данными из текущейй строки 
                        Convert.ToInt32(reader["product_id"]),
                        reader["manufacturer_name"].ToString(),
                        reader["product_name"].ToString(),
                        reader["category_name"].ToString(),
                        Convert.ToInt32(reader["available_quantity"]),
                        reader["composition"].ToString(),
                        Convert.ToDecimal(reader["current_price"]),
                        reader["image_file"].ToString());

                flowLayoutPanel1.Controls.Add(userControl); //вставляем карточку на гл. форму

            }
            reader.Close();
            sqlConnection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection sqlConnection = new SqlConnection(connection); //объект подключения
            sqlConnection.Open(); //открываем соединение с бд

            string query = @"SELECT DISTINCT
                           products.product_name, 
                           products.current_price, 
                           products.image_file, 
                           products.composition, 
                           manufacturers.manufacturer_name, 
                           categories.category_name,
                           stock_items.available_quantity
                           FROM products
                           JOIN manufacturers ON products.manufacturer_id = manufacturers.manufacturer_id
                           JOIN subcategories ON products.subcategory_id = subcategories.subcategory_id
                           JOIN stock_items ON stock_items.product_id = products.product_id
                           JOIN categories ON subcategories.category_id = categories.category_id"; //запрос sql, distinct убирает дубли, join склеивает таблицы

            if (comboBox1.SelectedIndex == 1)
                query += " ORDER BY current_price ASC";
            else if (comboBox1.SelectedIndex == 2)
                query += " ORDER BY current_price DESC";

            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();

            flowLayoutPanel1.Controls.Clear();

            while (reader.Read()) //проходим по кадой строке результата заброса, пока есть данные
            {
                UserControl1 userControl = new UserControl1(); //создание нов-го экземпляра поль з-го эл-та упр-я

                userControl.Card( //вызываем метод. заполняем катрочку данными из текущейй строки 
                        Convert.ToInt32(reader["product_id"]),
                        reader["manufacturer_name"].ToString(),
                        reader["product_name"].ToString(),
                        reader["category_name"].ToString(),
                        Convert.ToInt32(reader["available_quantity"]),
                        reader["composition"].ToString(),
                        Convert.ToDecimal(reader["current_price"]),
                        reader["image_file"].ToString());

                flowLayoutPanel1.Controls.Add(userControl); //вставляем карточку на гл. форму

            }

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection sqlConnection = new SqlConnection(connection);
            sqlConnection.Open();

            string query = @"SELECT DISTINCT
                           products.product_name, 
                           products.current_price, 
                           products.image_file, 
                           products.composition, 
                           manufacturers.manufacturer_name, 
                           categories.category_name,
                           stock_items.available_quantity
                           FROM products
                           JOIN manufacturers ON products.manufacturer_id = manufacturers.manufacturer_id
                           JOIN subcategories ON products.subcategory_id = subcategories.subcategory_id
                           JOIN stock_items ON stock_items.product_id = products.product_id
                           JOIN categories ON subcategories.category_id = categories.category_id";
            if (comboBox2.SelectedIndex == 1)
                query += " WHERE category_name = 'Детская обувь'";
            else if (comboBox2.SelectedIndex == 2)
                query += " WHERE category_name = 'Женская обувь'";
            else if (comboBox2.SelectedIndex == 3)
                query += " WHERE category_name = 'Мужская обувь'";


            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();

            flowLayoutPanel1.Controls.Clear();

           while (reader.Read()) //проходим по кадой строке результата заброса, пока есть данные
            {
                UserControl1 userControl = new UserControl1(); //создание нов-го экземпляра поль з-го эл-та упр-я

                userControl.Card( //вызываем метод. заполняем катрочку данными из текущейй строки 
                        Convert.ToInt32(reader["product_id"]),
                        reader["manufacturer_name"].ToString(),
                        reader["product_name"].ToString(),
                        reader["category_name"].ToString(),
                        Convert.ToInt32(reader["available_quantity"]),
                        reader["composition"].ToString(),
                        Convert.ToDecimal(reader["current_price"]),
                        reader["image_file"].ToString());

                flowLayoutPanel1.Controls.Add(userControl); //вставляем карточку на гл. форму

            }



        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string search = textBox1.Text.Trim();
            SqlConnection sqlConnection = new SqlConnection(connection);
            sqlConnection.Open();

            string query = @"SELECT DISTINCT
                           products.product_name, 
                           products.current_price, 
                           products.image_file, 
                           products.composition, 
                           manufacturers.manufacturer_name, 
                           categories.category_name,
                           stock_items.available_quantity
                           FROM products
                           JOIN manufacturers ON products.manufacturer_id = manufacturers.manufacturer_id
                           JOIN subcategories ON products.subcategory_id = subcategories.subcategory_id
                           JOIN stock_items ON stock_items.product_id = products.product_id
                           JOIN categories ON subcategories.category_id = categories.category_id 
                           WHERE product_name LIKE @search
                           OR composition LIKE @search";
            string searchPatten = "%" + search + "%";

            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            sqlCommand.Parameters.AddWithValue("search", searchPatten);
            SqlDataReader reader = sqlCommand.ExecuteReader();

            flowLayoutPanel1.Controls.Clear();

            while (reader.Read()) //проходим по кадой строке результата заброса, пока есть данные
            {
                UserControl1 userControl = new UserControl1(); //создание нов-го экземпляра поль з-го эл-та упр-я

                userControl.Card( //вызываем метод. заполняем катрочку данными из текущейй строки 
                        Convert.ToInt32(reader["product_id"]),
                        reader["manufacturer_name"].ToString(),
                        reader["product_name"].ToString(),
                        reader["category_name"].ToString(),
                        Convert.ToInt32(reader["available_quantity"]),
                        reader["composition"].ToString(),
                        Convert.ToDecimal(reader["current_price"]),
                        reader["image_file"].ToString());

                flowLayoutPanel1.Controls.Add(userControl); //вставляем карточку на гл. форму

            }
        }
    }
}
